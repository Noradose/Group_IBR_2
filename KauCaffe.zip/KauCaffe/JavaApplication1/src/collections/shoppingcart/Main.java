package collections.shoppingcart;

import java.io.IOException;

public class Main {
    
     public static void main (String [] args) throws IOException{
        UI ui = new UI();
    }
}