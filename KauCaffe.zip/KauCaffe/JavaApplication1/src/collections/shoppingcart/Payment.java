/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package collections.shoppingcart;

import java.util.Scanner;

/**
 *
 * @author suser
 */
public class Payment {
    String Location ="";
    int timeDelivery;
    public void deliveryLocation(){
    System.out.println("Kindly enter your delivery address below: ");
    Scanner S = new Scanner(System.in);
    Location = S.next();
    }
    
    public void setDeliverTime(){
    System.out.println("Choose prefferable delivery time: ");
    System.out.println("_______________________________________");
    System.out.println("1-   9:00 AM to 3:00 PM");
    System.out.println("2-   5:00 PM to 10:00 PM");
    System.out.println("_______________________________________");
    Scanner S = new Scanner(System.in);
    timeDelivery = S.nextInt();
    }
    
    public void confirmPayment(){
    Cart C = new Cart();
    C.printCartItems();
    System.out.println("_______________________________________");
    System.out.println("The order will be delivered to "+Location);
    if (timeDelivery == 1){
    System.out.println(" between  9:00 AM to 3:00 PM");
    }
    else if(timeDelivery == 2){
    System.out.println(" between  5:00 PM to 10:00 PM");
    }
    System.out.print("Thank you, and hope to see you soon.");
    }
    
}
