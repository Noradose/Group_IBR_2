package collections.shoppingcart;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

class Cart {

    List<Product> cartItems = new ArrayList<>();
    
    public void addProductToCartByPID(int pid) throws IOException {
        Product product = getProductByProductID(pid);
        product.setQuantity();
        addToCart(product);
    }

    private Product getProductByProductID(int pid) throws IOException {
        Product product = null;
        List<Product> products = new Products().getProducts();
        for (Product prod: products) {
            if (prod.getPid() == pid) {
                product = prod;
                break;
            }
        }
        return product;
    }

    private void addToCart(Product product) {
        cartItems.add(product);
    }

    public void removeProductByPID(int pid) throws IOException {
        Product prod = getProductByProductID(pid);
        cartItems.remove(prod);
    }
 double total = 0;
 double bill = 0;
    void printCartItems() {
       
        
        for (Product prod: cartItems) {
            System.out.print(prod.getName()+" "+prod.getQuantity()+" Pcs. Price: "+prod.getPrice()+" SAR");
            total+=prod.getPrice()*prod.getQuantity();
            System.out.println(" total price: "+total+" SAR");
            bill+=total;
        }
        System.out.println("Total bill: "+bill+" SAR");
    }
    
}