package collections.shoppingcart;

import java.util.ArrayList;
import java.util.List;


public final class Products {
    private final List<Product> products = new ArrayList<Product>();

    public Products () {
        this.initStoreItems();
    }
    
    public List<Product> getProducts() {
        return products;
    }
    
    public void initStoreItems() {
        String [] productNames = {"Latte", "Hot Mocha", "Cappuccino","Karak Tea", "Hot Chocolate", "Iced Coffee"
                                   ,"Iced Latte", "Iced Mocha", "Iced Caramel Macchiato","Strawberry Frappe", "Ice Cream",
                                   "Apple Pie","Cheesecake", "Chocolate Cookies", "Stick Waffle","Espresso", "Arabica", "Robusta","Liberica","Excelsa"};
        Double [] productPrice = {20.00d, 12.00d, 10.00d,5.00d, 10.00d, 12.00d,23.00d, 16.00d, 17.00d,20.00d, 25.00d, 20.00d
        ,17.00d, 16.00d, 18.00d,12.00d, 7.00d, 15.00d,12.00d, 12.00d};
        Integer [] stock = {100, 150, 200, 50, 80, 100, 100, 100, 300,40, 30, 100,70, 150, 100,200, 300, 60,40,20};

     
        for (int i=0; i < productNames.length; i++) {
            this.products.add(new Product(i+1, productNames[i], productPrice[i], stock[i]));
        }
    }
}